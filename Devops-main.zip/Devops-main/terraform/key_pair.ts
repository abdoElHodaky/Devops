/*resource "aws_key_pair" "keypr_a_resrce" {
  key_name=output.keypr_a_name
  public_key=output.keypr_a.pa
}*/
