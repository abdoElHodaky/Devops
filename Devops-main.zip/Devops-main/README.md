# DevOps Infrastructure & Deployment Pipeline

A comprehensive DevOps repository implementing Infrastructure as Code (IaC) and GitOps practices for deploying a NestCMS application on AWS EKS using Terraform, Kubernetes, and FluxCD.

## 🏗️ Architecture Overview

This repository provides a complete cloud-native deployment pipeline featuring:

- **Infrastructure**: AWS EKS cluster provisioned with Terraform
- **CI/CD**: Dual pipeline approach using GitHub Actions and CircleCI
- **GitOps**: FluxCD for continuous deployment and synchronization
- **Application**: NestCMS containerized application
- **Orchestration**: Kubernetes for container orchestration

## 📋 Prerequisites

### Required Tools
- [Terraform](https://www.terraform.io/downloads.html) >= 1.0
- [kubectl](https://kubernetes.io/docs/tasks/tools/) >= 1.32
- [AWS CLI](https://aws.amazon.com/cli/) configured with appropriate credentials
- [Docker](https://docs.docker.com/get-docker/) for local development
- [FluxCD CLI](https://fluxcd.io/flux/installation/) >= 2.6.4

### Required Accounts & Access
- AWS Account with EKS permissions
- GitHub account with repository access
- Docker Hub account for container registry
- CircleCI account (if using CircleCI pipeline)

### Environment Variables
Configure the following secrets in your CI/CD platform:

```bash
# AWS Configuration
TF_VAR_AWS_ACCESS_KEY      # AWS Access Key ID
TF_VAR_AWS_ACCESS_SECRET   # AWS Secret Access Key
TF_VAR_AWS_REGION          # AWS Region (default: eu-central-1)

# Cluster Configuration
TF_VAR_EKS_CLUSTER_NAME    # EKS Cluster Name

# Container Registry Access
TF_VAR_DOCKER_PAT          # Docker Hub Personal Access Token
TF_VAR_GHCR_PAT           # GitHub Container Registry PAT

# Terraform Cloud (if using)
TF_API_TOKEN              # Terraform Cloud API Token
```

## 🚀 Quick Start

### 1. Infrastructure Deployment

Deploy the AWS EKS infrastructure using Terraform:

```bash
# Navigate to terraform directory
cd terraform

# Initialize Terraform
terraform init

# Plan the deployment
terraform plan

# Apply the configuration
terraform apply --auto-approve
```

### 2. Application Deployment Options

#### Option A: GitHub Actions Pipeline

1. **Trigger Terraform Plan Workflow**:
   - Go to Actions tab in GitHub
   - Run "Terraform-Plan" workflow manually
   - This provisions the EKS cluster and related AWS resources

2. **Automatic Kubernetes Deployment**:
   - The "kube" workflow triggers automatically after successful Terraform plan
   - Deploys the NestCMS application to the EKS cluster
   - Configures ingress and load balancer

#### Option B: CircleCI + FluxCD Pipeline

1. **FluxCD Setup**:
   - The CircleCI pipeline creates a Kind cluster for testing
   - Installs FluxCD components
   - Syncs with the [FluxCD repository](https://github.com/abdoElHodaky/Fluxcd)

2. **Application Deployment**:
   - FluxCD automatically deploys the NestCMS application
   - Manages Kubernetes resources through GitOps principles

## 📁 Repository Structure

```
.
├── .circleci/
│   └── config.yml              # CircleCI pipeline configuration
├── .github/
│   └── workflows/
│       ├── kube.yaml          # Kubernetes deployment workflow
│       ├── terraform-pa.yml   # Terraform plan & apply
│       └── terraform-pd.yml   # Terraform destroy
├── terraform/
│   ├── cluster.tf             # EKS cluster configuration
│   ├── kube_deployment.tf     # Kubernetes deployment resources
│   ├── kube_service.tf        # Kubernetes service configuration
│   ├── kube_secrets.tf        # Kubernetes secrets management
│   ├── variables.tf           # Terraform variables
│   ├── outputs.tf             # Terraform outputs
│   └── *.yaml                 # Kubernetes manifests
└── README.md                  # This file
```

## 🔧 Infrastructure Components

### AWS Resources
- **EKS Cluster**: Managed Kubernetes cluster with auto-scaling
- **IAM Roles**: Cluster and node group service roles
- **VPC Integration**: Uses existing VPC subnets
- **Load Balancer**: Application Load Balancer for ingress

### Kubernetes Resources
- **Deployment**: NestCMS application deployment
- **Service**: LoadBalancer service for external access
- **Ingress**: Ingress controller for routing
- **Secrets**: Docker registry and application secrets

## 🔄 CI/CD Workflows

### GitHub Actions Workflows

1. **Terraform-Plan** (`terraform-pa.yml`):
   - Triggered manually via `workflow_dispatch`
   - Provisions AWS infrastructure
   - Commits state changes back to repository

2. **Kubernetes Deployment** (`kube.yaml`):
   - Triggered after successful Terraform workflow
   - Deploys application to EKS cluster
   - Updates ingress and service configurations

### CircleCI Workflow

1. **FluxCD Integration** (`.circleci/config.yml`):
   - Creates Kind cluster for testing
   - Installs FluxCD components
   - Syncs with GitOps repository
   - Deploys NestCMS application

## 🐳 Application Details

### NestCMS Application
- **Image**: `abdoelhodaky/nestcms:latest`
- **Port**: 3000
- **Resources**: 
  - Requests: 256Mi memory, 250m CPU
  - Limits: 512Mi memory, 500m CPU

### Service Configuration
- **Type**: LoadBalancer
- **External Access**: Via AWS Application Load Balancer
- **Ingress**: Configured for HTTP/HTTPS traffic

## 🔐 Security Considerations

- IAM roles follow least privilege principle
- Kubernetes secrets for sensitive data
- Docker registry authentication
- VPC security groups for network isolation

## 🛠️ Development Workflow

1. **Infrastructure Changes**:
   ```bash
   # Make changes to Terraform files
   cd terraform
   terraform plan
   terraform apply
   ```

2. **Application Updates**:
   - Update container image in `kube_deployment.tf`
   - Commit changes to trigger CI/CD pipeline
   - Monitor deployment through kubectl or AWS console

3. **Configuration Changes**:
   - Update Kubernetes manifests in terraform directory
   - Changes are applied through CI/CD workflows

## 📊 Monitoring & Troubleshooting

### Useful Commands

```bash
# Check cluster status
kubectl get nodes --kubeconfig="./terraform/kubeconfig.yaml"

# Check application status
kubectl get pods -l app=nestcms --kubeconfig="./terraform/kubeconfig.yaml"

# Check service endpoints
kubectl get svc nestcms-loadbalancer --kubeconfig="./terraform/kubeconfig.yaml"

# View application logs
kubectl logs -l app=nestcms --kubeconfig="./terraform/kubeconfig.yaml"
```

### Common Issues

1. **EKS Cluster Access**: Ensure AWS credentials have EKS permissions
2. **Docker Registry**: Verify Docker Hub credentials are correctly configured
3. **FluxCD Sync**: Check FluxCD repository access and webhook configuration
4. **Load Balancer**: Allow time for AWS ALB provisioning (5-10 minutes)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test with `terraform plan`
5. Submit a pull request

## 📚 Additional Resources

- [AWS EKS Documentation](https://docs.aws.amazon.com/eks/)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
- [FluxCD Documentation](https://fluxcd.io/flux/)
- [Kubernetes Documentation](https://kubernetes.io/docs/)

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

**Note**: This repository demonstrates a production-ready DevOps pipeline. Ensure you understand the AWS costs associated with running EKS clusters before deployment.

